"""
openai_engine.py
─────────────────────────────────────────────────────────────────────────────
OpenAI-powered symptom extraction and disease prediction pipeline.

Key capabilities:
  • AI symptom extraction  — no fixed keyword list; understands ANY language,
    slang, regional terms, abbreviations, multi-language mixed input
  • Unlimited disease prediction — not restricted to the 10 pre-trained classes;
    can identify rare, complex, or multi-system conditions
  • Structured JSON responses  — parsed and validated before returning
  • Three-layer pipeline:
      1. GPT extracts & normalises symptoms from free text
      2. GPT predicts disease(s) with confidence, urgency, and advice
      3. GPT generates follow-up chatbot replies (used by chatbot route)
  • Safe fallback — if OpenAI is unavailable or API key missing, the app
    automatically falls back to the local ML model (symptom_checker.py)
─────────────────────────────────────────────────────────────────────────────
"""

import os
import json
import re
import time
from datetime import datetime

# ── OpenAI client ─────────────────────────────────────────────────────────────
try:
    from openai import OpenAI
    _openai_available = True
except ImportError:
    _openai_available = False

OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY", "")
_client = None

def get_client():
    global _client
    if _client is None and _openai_available and OPENAI_API_KEY:
        _client = OpenAI(api_key=OPENAI_API_KEY)
    return _client

def is_openai_ready() -> bool:
    return _openai_available and bool(OPENAI_API_KEY)


# ── Urgency colour map ────────────────────────────────────────────────────────
URGENCY_COLORS = {
    "low":      "#22c55e",
    "medium":   "#f59e0b",
    "high":     "#ef4444",
    "critical": "#dc2626",
}


# ═══════════════════════════════════════════════════════════════════════════════
# STEP 1 — AI SYMPTOM EXTRACTION
# ═══════════════════════════════════════════════════════════════════════════════
SYMPTOM_EXTRACTION_SYSTEM = """You are a medical NLP engine. Your ONLY job is to extract
symptoms from patient-provided text and return clean JSON.

Rules:
- Extract ALL medical symptoms mentioned, implied, or described colloquially
- Normalise to standard medical terminology (e.g. "tummy ache" → "abdominal pain")
- Include severity qualifiers when present (e.g. "severe headache", "mild fever")
- Include duration when present (e.g. "cough for 3 days")
- Handle any language, slang, abbreviations, regional expressions
- Do NOT add symptoms that were not mentioned
- Return ONLY valid JSON, no markdown, no explanation

Output format (strict JSON):
{
  "symptoms": ["symptom 1", "symptom 2", ...],
  "symptom_details": [
    {"symptom": "headache", "severity": "severe", "duration": "2 days", "notes": "with aura"},
    ...
  ],
  "patient_context": "brief 1-sentence summary of what the patient described",
  "language_detected": "English",
  "extraction_confidence": 0.95
}"""


def ai_extract_symptoms(text: str) -> dict:
    """
    Use GPT to extract symptoms from ANY free text.
    Returns dict with 'symptoms' list and enriched details.
    Falls back to empty structure on failure.
    """
    client = get_client()
    if not client:
        return {"symptoms": [], "symptom_details": [], "patient_context": text,
                "language_detected": "unknown", "extraction_confidence": 0.0,
                "openai_used": False}

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": SYMPTOM_EXTRACTION_SYSTEM},
                {"role": "user",   "content": f"Extract symptoms from:\n\n{text}"}
            ],
            temperature=0.1,
            max_tokens=800,
            response_format={"type": "json_object"}
        )
        raw = response.choices[0].message.content
        data = json.loads(raw)
        data["openai_used"] = True
        data["openai_model"] = "gpt-4o-mini"
        return data

    except Exception as e:
        return {
            "symptoms": [],
            "symptom_details": [],
            "patient_context": text,
            "language_detected": "unknown",
            "extraction_confidence": 0.0,
            "openai_used": False,
            "error": str(e)
        }


# ═══════════════════════════════════════════════════════════════════════════════
# STEP 2 — AI DISEASE PREDICTION PIPELINE
# ═══════════════════════════════════════════════════════════════════════════════
DISEASE_PREDICTION_SYSTEM = """You are an expert AI medical diagnostic assistant.
Given a list of symptoms and the patient's original description, predict the most
likely medical condition(s) and provide actionable health guidance.

IMPORTANT RULES:
- You can predict ANY condition — common, rare, or complex — not just a fixed list
- Consider symptom combinations, severity, duration, and context
- Always provide a PRIMARY diagnosis and 2 ALTERNATIVE possibilities
- Be medically accurate but use plain language for recommendations
- Urgency levels: low (home care), medium (see doctor soon), high (urgent care), critical (ER now)
- Never claim to replace a real doctor
- Return ONLY valid JSON, no markdown, no explanation

Output format (strict JSON):
{
  "primary_diagnosis": {
    "disease": "Condition Name",
    "icd_hint": "approximate ICD category e.g. J06.9",
    "confidence": 0.85,
    "confidence_pct": "85%",
    "urgency": "medium",
    "urgency_reason": "Symptoms suggest bacterial infection that needs antibiotic treatment",
    "see_doctor": true,
    "recommendation": "Full paragraph recommendation in plain language",
    "self_care_tips": ["tip 1", "tip 2", "tip 3", "tip 4"],
    "red_flags": ["warning sign 1 that means go to ER"],
    "typical_duration": "5-7 days with treatment",
    "contagious": false,
    "specialist": "General Practitioner"
  },
  "alternatives": [
    {"disease": "Alternative 1", "confidence": 0.10, "reason": "why this is possible"},
    {"disease": "Alternative 2", "confidence": 0.05, "reason": "why this is possible"}
  ],
  "matched_symptoms": ["normalised symptom 1", "normalised symptom 2"],
  "unrecognised_symptoms": [],
  "overall_assessment": "One sentence summary for the patient",
  "disclaimer": "This is AI-generated information only, not a medical diagnosis.",
  "analysis_notes": "Any important clinical notes or caveats"
}"""


def ai_predict_disease(symptoms: list, symptom_details: list, original_text: str) -> dict:
    """
    Use GPT to predict disease from extracted symptoms — unlimited conditions.
    Returns full structured prediction dict.
    """
    client = get_client()
    if not client:
        return None

    # Build rich prompt
    symptom_block = "\n".join(f"  - {s}" for s in symptoms) if symptoms else "  (none extracted)"
    detail_block  = json.dumps(symptom_details, indent=2) if symptom_details else "[]"

    user_prompt = f"""Patient description:
\"\"\"{original_text}\"\"\"

Extracted symptoms:
{symptom_block}

Symptom details (with severity/duration):
{detail_block}

Please diagnose and provide full health guidance."""

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": DISEASE_PREDICTION_SYSTEM},
                {"role": "user",   "content": user_prompt}
            ],
            temperature=0.2,
            max_tokens=1500,
            response_format={"type": "json_object"}
        )
        raw  = response.choices[0].message.content
        data = json.loads(raw)

        # ── Normalise into the app's standard result schema ──────────────────
        primary = data.get("primary_diagnosis", {})
        alts    = data.get("alternatives", [])

        # Build top3 list (same shape as local ML model)
        top3 = [
            {"disease": primary.get("disease","Unknown"),
             "confidence": primary.get("confidence", 0.8)}
        ]
        for alt in alts[:2]:
            top3.append({
                "disease": alt.get("disease",""),
                "confidence": alt.get("confidence", 0.1)
            })

        urgency = primary.get("urgency","medium")

        result = {
            # ── Core fields (same as local ML schema) ──
            "disease":          primary.get("disease","Unknown"),
            "confidence":       primary.get("confidence", 0.8),
            "confidence_pct":   primary.get("confidence_pct",
                                f"{primary.get('confidence',0.8):.1%}"),
            "urgency":          urgency,
            "urgency_color":    URGENCY_COLORS.get(urgency, "#f59e0b"),
            "recommendation":   primary.get("recommendation",""),
            "see_doctor":       primary.get("see_doctor", True),
            "tips":             primary.get("self_care_tips", []),
            "top3":             top3,
            "matched_symptoms": data.get("matched_symptoms", symptoms),

            # ── Extended OpenAI fields ──
            "openai_used":          True,
            "openai_model":         "gpt-4o-mini",
            "icd_hint":             primary.get("icd_hint",""),
            "urgency_reason":       primary.get("urgency_reason",""),
            "red_flags":            primary.get("red_flags",[]),
            "typical_duration":     primary.get("typical_duration",""),
            "contagious":           primary.get("contagious", False),
            "specialist":           primary.get("specialist","General Practitioner"),
            "overall_assessment":   data.get("overall_assessment",""),
            "analysis_notes":       data.get("analysis_notes",""),
            "unrecognised_symptoms":data.get("unrecognised_symptoms",[]),
            "disclaimer":           data.get("disclaimer",""),
            "alternatives":         alts,
            "raw_openai":           data,

            # HF fields default
            "hf_available": False,
        }
        return result

    except Exception as e:
        return {"error": "openai_prediction_failed", "message": str(e), "openai_used": True}


# ═══════════════════════════════════════════════════════════════════════════════
# STEP 3 — FULL PIPELINE (entry point called by app.py)
# ═══════════════════════════════════════════════════════════════════════════════
def openai_analyze(text: str) -> dict:
    """
    Full AI pipeline:
      text → GPT symptom extraction → GPT disease prediction → structured result

    Returns same schema as symptom_checker.analyze_text() so the rest of the
    app works identically regardless of which engine is used.
    """
    if not is_openai_ready():
        return {
            "error": "openai_unavailable",
            "message": "OpenAI API key not configured. Set OPENAI_API_KEY environment variable."
        }

    # Step 1: Extract symptoms
    extraction = ai_extract_symptoms(text)
    symptoms      = extraction.get("symptoms", [])
    symptom_details = extraction.get("symptom_details", [])

    if not symptoms:
        # GPT found nothing — try a relaxed pass
        relaxed = ai_extract_symptoms(
            f"Patient says: {text}\n\nExtract ANY health-related symptoms, even vague ones."
        )
        symptoms        = relaxed.get("symptoms", [])
        symptom_details = relaxed.get("symptom_details", [])

    if not symptoms:
        return {
            "error": "no_symptoms",
            "message": "No symptoms could be identified from your description. "
                       "Please describe what you are experiencing in more detail."
        }

    # Step 2: Predict disease
    result = ai_predict_disease(symptoms, symptom_details, text)

    if result is None:
        return {
            "error": "prediction_failed",
            "message": "AI prediction service is unavailable. Please try again."
        }

    # Attach extraction metadata
    result["extraction_confidence"] = extraction.get("extraction_confidence", 0.0)
    result["patient_context"]       = extraction.get("patient_context", "")
    result["language_detected"]     = extraction.get("language_detected", "")

    return result


# ═══════════════════════════════════════════════════════════════════════════════
# CHATBOT — GPT-powered replies (replaces rule-based when API key present)
# ═══════════════════════════════════════════════════════════════════════════════
CHATBOT_SYSTEM = """You are a knowledgeable, empathetic AI health assistant named HealthBot.

Your role:
- Answer health questions in plain, friendly language
- If a current diagnosis is provided, focus answers on that condition
- Cover any condition — not just a fixed list
- Give practical, evidence-based advice
- Always remind users to see a doctor for serious concerns
- Keep replies concise (3-6 sentences max) unless a detailed list is needed
- Use **bold** for key terms and • for lists
- NEVER claim to be a doctor or give prescriptions
- If the question is unrelated to health, politely redirect

You respond in the same language the user writes in."""


def openai_chatbot_reply(user_message: str, current_disease: str = None,
                          chat_history: list = None) -> str:
    """
    GPT-powered chatbot reply. Falls back to rule-based if unavailable.
    chat_history = list of {"role":"user"/"bot", "text":"..."} dicts
    """
    client = get_client()
    if not client:
        # Import and use rule-based fallback
        from huggingface_helper import chatbot_reply
        return chatbot_reply(user_message, current_disease)

    # Build messages array
    messages = [{"role": "system", "content": CHATBOT_SYSTEM}]

    # Add disease context
    if current_disease:
        messages.append({
            "role": "system",
            "content": f"The patient's current diagnosed/predicted condition is: {current_disease}. "
                       f"Tailor your answers to this condition when relevant."
        })

    # Add recent conversation history (last 10 exchanges)
    if chat_history:
        for msg in chat_history[-20:]:
            role = "user" if msg.get("role") == "user" else "assistant"
            messages.append({"role": role, "content": msg.get("text","")})

    # Add current message
    messages.append({"role": "user", "content": user_message})

    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=messages,
            temperature=0.5,
            max_tokens=500,
        )
        return response.choices[0].message.content.strip()

    except Exception as e:
        # Fallback to rule-based
        from huggingface_helper import chatbot_reply
        return chatbot_reply(user_message, current_disease)


# ═══════════════════════════════════════════════════════════════════════════════
# REAL-TIME SYMPTOM EXTRACTION (lightweight, for AJAX)
# ═══════════════════════════════════════════════════════════════════════════════
QUICK_EXTRACT_SYSTEM = """Extract symptoms from text. Return ONLY a JSON array of symptom strings.
Example: ["fever", "headache", "nausea"]
No explanation, no markdown."""

def ai_realtime_extract(text: str) -> list:
    """Fast extraction for real-time preview (cheaper, faster)."""
    client = get_client()
    if not client or len(text) < 8:
        return []
    try:
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": QUICK_EXTRACT_SYSTEM},
                {"role": "user",   "content": text}
            ],
            temperature=0.0,
            max_tokens=150,
        )
        raw = response.choices[0].message.content.strip()
        # Handle possible markdown wrapping
        raw = re.sub(r"```json|```","", raw).strip()
        data = json.loads(raw)
        if isinstance(data, list):
            return [str(s) for s in data]
        return []
    except Exception:
        return []


# ═══════════════════════════════════════════════════════════════════════════════
# ENGINE STATUS
# ═══════════════════════════════════════════════════════════════════════════════
def engine_status() -> dict:
    """Return which AI engines are available."""
    return {
        "openai_sdk":      _openai_available,
        "openai_key_set":  bool(OPENAI_API_KEY),
        "openai_ready":    is_openai_ready(),
        "model":           "gpt-4o-mini" if is_openai_ready() else None,
        "fallback":        "Local RandomForest ML model",
    }
