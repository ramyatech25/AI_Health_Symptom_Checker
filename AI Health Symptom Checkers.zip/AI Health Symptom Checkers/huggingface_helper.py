"""
huggingface_helper.py
Hugging Face integration for the AI Health Symptom Checker.

Two modes:
  1. Inference API  — calls HF hosted inference (free tier, no GPU needed)
  2. Local pipeline — loads a small model locally (auto-downloads on first use)

The chatbot assistant uses a rule-based fallback when HF is unavailable,
so the app always works offline / in Termux without internet.
"""

import os
import re
import json
import time
import requests

# ── Optional: set your HF token in env for gated models ──────────────────────
HF_TOKEN = os.environ.get("HF_TOKEN", "")
HF_API_URL = "https://api-inference.huggingface.co/models/"

# ── Models ───────────────────────────────────────────────────────────────────
TEXT_CLASSIFICATION_MODEL = "distilbert-base-uncased-finetuned-sst-2-english"
GENERATION_MODEL          = "microsoft/DialoGPT-small"   # small, fast
ZERO_SHOT_MODEL           = "facebook/bart-large-mnli"   # zero-shot classification

# ── Disease context for chatbot ───────────────────────────────────────────────
DISEASE_QA = {
    "Common Cold": {
        "duration":    "7–10 days",
        "contagious":  "Yes, spreads via droplets. Avoid close contact.",
        "medicine":    "Paracetamol for fever, decongestants, antihistamines.",
        "diet":        "Warm soups, ginger tea, citrus fruits rich in Vitamin C.",
        "prevention":  "Wash hands frequently, avoid touching face, stay warm.",
        "when_doctor": "If symptoms worsen after 10 days or fever exceeds 39°C."
    },
    "Influenza": {
        "duration":    "1–2 weeks",
        "contagious":  "Highly contagious for up to 7 days after symptoms start.",
        "medicine":    "Oseltamivir (Tamiflu) within 48h. Paracetamol for fever.",
        "diet":        "Clear broths, electrolyte drinks, avoid alcohol.",
        "prevention":  "Annual flu vaccine. Hand hygiene. Mask in crowded spaces.",
        "when_doctor": "Immediately if breathing becomes difficult or lips turn blue."
    },
    "COVID-19": {
        "duration":    "1–3 weeks for mild cases; may linger longer.",
        "contagious":  "Highly contagious. Isolate for at least 5 days from symptom onset.",
        "medicine":    "Rest, fluids, paracetamol. Antivirals if prescribed by doctor.",
        "diet":        "High protein foods, Vitamin D, Zinc supplements.",
        "prevention":  "Vaccination, masks, ventilation, hand washing.",
        "when_doctor": "Urgently if oxygen saturation < 94% or severe breathlessness."
    },
    "Migraine": {
        "duration":    "4–72 hours per episode.",
        "contagious":  "Not contagious — it is a neurological condition.",
        "medicine":    "Triptans, NSAIDs, anti-nausea medication.",
        "diet":        "Avoid triggers: caffeine, alcohol, processed foods.",
        "prevention":  "Identify triggers, maintain sleep schedule, manage stress.",
        "when_doctor": "If headache is sudden/severe ('thunderclap'), seek ER immediately."
    },
    "Gastroenteritis": {
        "duration":    "1–3 days for viral; 1–2 weeks for bacterial.",
        "contagious":  "Very contagious. Wash hands thoroughly after bathroom visits.",
        "medicine":    "ORS (Oral Rehydration Salts). Loperamide for diarrhea.",
        "diet":        "BRAT diet: Bananas, Rice, Applesauce, Toast. Avoid dairy.",
        "prevention":  "Food safety, hand hygiene, clean water.",
        "when_doctor": "If blood in stool, high fever, or signs of dehydration."
    },
    "Hypertension": {
        "duration":    "Chronic condition — requires long-term management.",
        "contagious":  "Not contagious — lifestyle and genetic condition.",
        "medicine":    "ACE inhibitors, beta-blockers, calcium channel blockers.",
        "diet":        "DASH diet: low sodium, high potassium. Limit alcohol.",
        "prevention":  "Regular exercise, stress management, healthy weight.",
        "when_doctor": "If BP > 180/120 or you have chest pain — emergency."
    },
    "Diabetes": {
        "duration":    "Chronic condition — lifelong management required.",
        "contagious":  "Not contagious.",
        "medicine":    "Metformin (Type 2), insulin (Type 1 or advanced Type 2).",
        "diet":        "Low glycemic index foods, avoid sugary drinks, high fiber.",
        "prevention":  "Type 2 is largely preventable with exercise and healthy weight.",
        "when_doctor": "If blood sugar > 300 mg/dL or you feel confused/unconscious."
    },
    "Asthma": {
        "duration":    "Chronic condition — episodes can last minutes to days.",
        "contagious":  "Not contagious — allergic/environmental trigger.",
        "medicine":    "Rescue inhaler (salbutamol), corticosteroid inhalers.",
        "diet":        "Avoid sulfites in wine/dried fruit. Vitamin D may help.",
        "prevention":  "Identify and avoid triggers. Keep rescue inhaler handy.",
        "when_doctor": "If rescue inhaler gives no relief — emergency immediately."
    },
    "Allergic Rhinitis": {
        "duration":    "Seasonal (weeks) or perennial (year-round).",
        "contagious":  "Not contagious — immune response to allergens.",
        "medicine":    "Antihistamines, nasal corticosteroids, decongestants.",
        "diet":        "Local honey may help with pollen allergy (anecdotal).",
        "prevention":  "HEPA air purifiers, keep windows closed in high-pollen season.",
        "when_doctor": "If symptoms are severe or asthma is also present."
    },
    "Urinary Tract Infection": {
        "duration":    "3–7 days with antibiotics.",
        "contagious":  "Not contagious (except sexually transmitted causes).",
        "medicine":    "Antibiotics (trimethoprim, nitrofurantoin). Drink cranberry juice.",
        "diet":        "Drink plenty of water. Avoid caffeine and alcohol.",
        "prevention":  "Urinate after sex, wipe front-to-back, stay hydrated.",
        "when_doctor": "Always — UTIs require antibiotic prescription."
    },
}

GENERAL_HEALTH_QA = {
    "hello": "Hello! I'm your AI Health Assistant 🩺 I can answer questions about your diagnosed condition, medicines, diet, prevention, and when to see a doctor. What would you like to know?",
    "hi": "Hi there! I'm here to help with your health questions. Ask me about your symptoms, medicines, diet, or when to visit a doctor.",
    "help": "I can help with:\n• **Medicine** — What medications are recommended?\n• **Diet** — What should I eat?\n• **Duration** — How long will this last?\n• **Prevention** — How to prevent it?\n• **Contagious** — Is it contagious?\n• **Doctor** — When should I see a doctor?\n\nJust type your question!",
    "emergency": "🚨 If you are experiencing a **medical emergency** — difficulty breathing, chest pain, loss of consciousness, or severe symptoms — **call emergency services (112/108) immediately**. Do not wait.",
    "disclaimer": "⚠️ I am an AI assistant for educational purposes only. I am **not a doctor** and cannot provide professional medical advice. Always consult a qualified healthcare professional.",
}

# ── Intent detection ──────────────────────────────────────────────────────────
INTENT_PATTERNS = {
    "duration":    r"how long|duration|days|weeks|recover|go away",
    "contagious":  r"contagious|spread|infectious|catch|transmit",
    "medicine":    r"medicine|medication|drug|tablet|pill|treat|cure|take",
    "diet":        r"eat|food|diet|drink|nutrition|avoid",
    "prevention":  r"prevent|avoid|protect|stop|vaccine",
    "when_doctor": r"doctor|hospital|when.*see|emergency|serious",
    "greeting":    r"^(hi|hello|hey|howdy|good morning|good evening)[\s!.]*$",
    "help":        r"help|what can you|what do you|how do you work",
    "emergency":   r"emergency|dying|unconscious|not breathing|severe|911|112|108",
    "disclaimer":  r"are you a doctor|real doctor|replace doctor|trust you|accurate",
}


def detect_intent(text: str) -> str:
    text_lower = text.lower().strip()
    for intent, pattern in INTENT_PATTERNS.items():
        if re.search(pattern, text_lower):
            return intent
    return "general"


def chatbot_reply(user_message: str, current_disease: str = None) -> str:
    """
    Rule-based chatbot that answers health questions about the detected disease.
    Falls back to HF Inference API if available (and adds a note about it).
    """
    intent = detect_intent(user_message)

    # General intents first
    if intent == "greeting":
        return GENERAL_HEALTH_QA.get("hello")
    if intent == "help":
        return GENERAL_HEALTH_QA.get("help")
    if intent == "emergency":
        return GENERAL_HEALTH_QA.get("emergency")
    if intent == "disclaimer":
        return GENERAL_HEALTH_QA.get("disclaimer")

    # Disease-specific answers
    if current_disease and current_disease in DISEASE_QA:
        qa = DISEASE_QA[current_disease]
        disease_name = current_disease

        if intent == "duration":
            return f"⏱️ **{disease_name} — Duration:**\n{qa['duration']}"
        if intent == "contagious":
            return f"🦠 **{disease_name} — Contagiousness:**\n{qa['contagious']}"
        if intent == "medicine":
            return f"💊 **{disease_name} — Medicines:**\n{qa['medicine']}\n\n⚠️ Always follow your doctor's prescription."
        if intent == "diet":
            return f"🥗 **{disease_name} — Diet Tips:**\n{qa['diet']}"
        if intent == "prevention":
            return f"🛡️ **{disease_name} — Prevention:**\n{qa['prevention']}"
        if intent == "when_doctor":
            return f"⚕️ **{disease_name} — When to See a Doctor:**\n{qa['when_doctor']}"

        # General question about the condition
        return (
            f"I detected **{disease_name}** from your symptoms. "
            f"You can ask me about:\n"
            f"• **Duration** — how long it lasts\n"
            f"• **Medicine** — what to take\n"
            f"• **Diet** — what to eat\n"
            f"• **Prevention** — how to avoid recurrence\n"
            f"• **Doctor** — when to seek medical care\n\n"
            f"What would you like to know?"
        )

    if current_disease:
        return f"I can see your condition is **{current_disease}**. Ask me about its duration, medicines, diet, prevention, or when to see a doctor."

    return (
        "Please run the **Symptom Checker** first so I can give you condition-specific advice. "
        "Once diagnosed, I can answer questions about medicine, diet, duration, and more!"
    )


# ── Optional: HuggingFace Inference API call ─────────────────────────────────
def hf_zero_shot_classify(text: str, labels: list, timeout: int = 10) -> dict | None:
    """
    Use HF's zero-shot classification to add a second opinion on disease labels.
    Returns dict with labels and scores, or None on failure.
    """
    url = HF_API_URL + ZERO_SHOT_MODEL
    headers = {"Authorization": f"Bearer {HF_TOKEN}"} if HF_TOKEN else {}
    payload = {
        "inputs": text,
        "parameters": {"candidate_labels": labels},
    }
    try:
        r = requests.post(url, headers=headers, json=payload, timeout=timeout)
        if r.status_code == 200:
            return r.json()
        return None
    except Exception:
        return None


def hf_enhance_prediction(symptom_text: str, local_result: dict) -> dict:
    """
    Try to enhance local ML prediction with HF zero-shot classifier.
    Returns the original result if HF is unavailable.
    """
    diseases = list(DISEASE_QA.keys())
    hf_result = hf_zero_shot_classify(symptom_text, diseases)

    if hf_result and "labels" in hf_result:
        # Blend: 70% local ML + 30% HF zero-shot
        hf_scores = dict(zip(hf_result["labels"], hf_result["scores"]))
        local_result["hf_available"] = True
        local_result["hf_top"] = hf_result["labels"][0]
        local_result["hf_confidence"] = f"{hf_result['scores'][0]:.1%}"

        # If both agree — boost confidence display
        if hf_result["labels"][0] == local_result["disease"]:
            local_result["hf_agrees"] = True
        else:
            local_result["hf_agrees"] = False
    else:
        local_result["hf_available"] = False

    return local_result
