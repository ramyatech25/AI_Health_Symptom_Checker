import os
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np

CHART_DIR = "charts"
os.makedirs(CHART_DIR, exist_ok=True)

PALETTE = {
    "primary": "#6366f1",
    "success": "#22c55e",
    "warning": "#f59e0b",
    "danger": "#ef4444",
    "bg": "#0f172a",
    "surface": "#1e293b",
    "text": "#f1f5f9",
    "muted": "#64748b",
}

def _apply_dark_style(fig, ax):
    fig.patch.set_facecolor(PALETTE["bg"])
    ax.set_facecolor(PALETTE["surface"])
    ax.tick_params(colors=PALETTE["text"])
    ax.xaxis.label.set_color(PALETTE["text"])
    ax.yaxis.label.set_color(PALETTE["text"])
    ax.title.set_color(PALETTE["text"])
    for spine in ax.spines.values():
        spine.set_edgecolor(PALETTE["muted"])


def confidence_bar_chart(top3: list, filename="confidence_chart.png"):
    """Horizontal bar chart of top-3 disease predictions."""
    diseases = [d["disease"] for d in top3]
    confs = [d["confidence"] * 100 for d in top3]
    colors = [PALETTE["primary"], PALETTE["warning"], PALETTE["muted"]]

    fig, ax = plt.subplots(figsize=(7, 3))
    _apply_dark_style(fig, ax)

    bars = ax.barh(diseases[::-1], confs[::-1], color=colors[::-1],
                   height=0.5, edgecolor="none")

    for bar, conf in zip(bars, confs[::-1]):
        ax.text(bar.get_width() + 1, bar.get_y() + bar.get_height() / 2,
                f"{conf:.1f}%", va="center", color=PALETTE["text"], fontsize=11, fontweight="bold")

    ax.set_xlim(0, 110)
    ax.set_xlabel("Confidence (%)", color=PALETTE["text"])
    ax.set_title("Prediction Confidence", color=PALETTE["text"], fontsize=13, pad=12)
    ax.axvline(50, color=PALETTE["muted"], linestyle="--", linewidth=0.8, alpha=0.5)

    plt.tight_layout()
    path = os.path.join(CHART_DIR, filename)
    fig.savefig(path, dpi=130, bbox_inches="tight")
    plt.close()
    return path


def symptom_radar_chart(symptoms_found: list, all_symptoms: list, filename="symptom_radar.png"):
    """Radar chart showing detected vs possible symptoms."""
    # Use top 10 most common symptoms for display
    display_symptoms = [
        "fever", "cough", "headache", "fatigue", "nausea",
        "dizziness", "chest pain", "shortness of breath", "sore throat", "body aches"
    ]
    N = len(display_symptoms)
    values = [1 if s in symptoms_found else 0 for s in display_symptoms]
    values += values[:1]

    angles = [n / float(N) * 2 * np.pi for n in range(N)]
    angles += angles[:1]

    fig, ax = plt.subplots(figsize=(5, 5), subplot_kw=dict(polar=True))
    fig.patch.set_facecolor(PALETTE["bg"])
    ax.set_facecolor(PALETTE["surface"])
    ax.set_xticks(angles[:-1])
    ax.set_xticklabels(display_symptoms, size=8, color=PALETTE["text"])
    ax.set_yticks([])
    ax.plot(angles, values, color=PALETTE["primary"], linewidth=2)
    ax.fill(angles, values, color=PALETTE["primary"], alpha=0.25)
    ax.spines["polar"].set_color(PALETTE["muted"])
    ax.set_title("Symptom Profile", color=PALETTE["text"], fontsize=12, pad=15)

    plt.tight_layout()
    path = os.path.join(CHART_DIR, filename)
    fig.savefig(path, dpi=130, bbox_inches="tight")
    plt.close()
    return path


def history_trend_chart(history: list, filename="history_trend.png"):
    """Bar chart of disease checks over time from user history."""
    if not history:
        return None

    from collections import Counter
    diseases = [h.get("disease", "Unknown") for h in history]
    counts = Counter(diseases)

    labels = list(counts.keys())
    values = list(counts.values())
    colors = [PALETTE["primary"], PALETTE["warning"], PALETTE["success"],
              PALETTE["danger"], PALETTE["muted"]][:len(labels)]

    fig, ax = plt.subplots(figsize=(8, 4))
    _apply_dark_style(fig, ax)

    bars = ax.bar(labels, values, color=colors, edgecolor="none", width=0.5)
    for bar, val in zip(bars, values):
        ax.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.1,
                str(val), ha="center", color=PALETTE["text"], fontsize=10)

    ax.set_ylabel("Times Checked", color=PALETTE["text"])
    ax.set_title("Your Check History", color=PALETTE["text"], fontsize=13, pad=12)
    plt.xticks(rotation=20, ha="right")
    plt.tight_layout()

    path = os.path.join(CHART_DIR, filename)
    fig.savefig(path, dpi=130, bbox_inches="tight")
    plt.close()
    return path
