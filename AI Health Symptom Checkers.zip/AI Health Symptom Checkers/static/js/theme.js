// Theme toggle — persists to localStorage
(function () {
  const root = document.documentElement;
  const btn = document.getElementById('themeToggle');
  const iconEl = btn ? btn.querySelector('.theme-icon') : null;

  function getTheme() {
    return localStorage.getItem('theme') || 'dark';
  }

  function setTheme(theme) {
    root.setAttribute('data-theme', theme);
    localStorage.setItem('theme', theme);
    if (iconEl) iconEl.textContent = theme === 'dark' ? '🌙' : '☀️';
  }

  // Apply on load
  setTheme(getTheme());

  if (btn) {
    btn.addEventListener('click', () => {
      setTheme(getTheme() === 'dark' ? 'light' : 'dark');
    });
  }

  // Auto-dismiss flash messages after 4s
  setTimeout(() => {
    document.querySelectorAll('.flash').forEach(el => {
      el.style.transition = 'opacity 0.4s';
      el.style.opacity = '0';
      setTimeout(() => el.remove(), 400);
    });
  }, 4000);
})();
