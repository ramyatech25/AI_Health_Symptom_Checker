#!/usr/bin/env python3
"""Terminal / CLI version of the AI Health Symptom Checker."""

import os
import sys
import time

# ── ANSI colors ───────────────────────────────────────────────────────────────
R  = "\033[91m"  # red
G  = "\033[92m"  # green
Y  = "\033[93m"  # yellow
B  = "\033[94m"  # blue
M  = "\033[95m"  # magenta
C  = "\033[96m"  # cyan
W  = "\033[97m"  # white
DIM = "\033[2m"
BOLD = "\033[1m"
RST = "\033[0m"

URGENCY_CLR = {"low": G, "medium": Y, "high": R}


def banner():
    print(f"""
{M}{BOLD}╔══════════════════════════════════════════════════════╗
║      🩺  AI HEALTH SYMPTOM CHECKER  v1.0             ║
║      Powered by Machine Learning                      ║
╚══════════════════════════════════════════════════════╝{RST}
{DIM}  ⚠  For informational purposes only. Not medical advice.{RST}
""")


def progress_bar(label="Analyzing", duration=1.5):
    steps = 30
    print(f"\n  {C}{label}{RST}  ", end="", flush=True)
    for i in range(steps + 1):
        pct = i / steps
        filled = int(pct * 20)
        bar = "█" * filled + "░" * (20 - filled)
        print(f"\r  {C}{label}{RST}  [{M}{bar}{RST}] {int(pct*100):3d}%", end="", flush=True)
        time.sleep(duration / steps)
    print()


def print_result(result):
    urgency = result.get("urgency", "medium")
    clr = URGENCY_CLR.get(urgency, Y)

    print(f"\n{W}{'─'*56}{RST}")
    print(f"  {BOLD}{W}DIAGNOSIS RESULT{RST}")
    print(f"{'─'*56}")
    print(f"  {DIM}Predicted Condition :{RST}  {BOLD}{M}{result['disease']}{RST}")
    print(f"  {DIM}Confidence          :{RST}  {BOLD}{G}{result['confidence_pct']}{RST}")
    print(f"  {DIM}Urgency             :{RST}  {BOLD}{clr}{urgency.upper()}{RST}")
    print(f"{'─'*56}")

    print(f"\n  {BOLD}{C}Symptoms Detected:{RST}")
    for s in result.get("matched_symptoms", []):
        print(f"    {G}•{RST} {s}")

    print(f"\n  {BOLD}{C}Recommendation:{RST}")
    rec = result.get("recommendation", "")
    # Word-wrap at 50 chars
    words = rec.split()
    line = "    "
    for word in words:
        if len(line) + len(word) > 55:
            print(f"{W}{line}{RST}")
            line = "    " + word + " "
        else:
            line += word + " "
    if line.strip():
        print(f"{W}{line}{RST}")

    print(f"\n  {BOLD}{C}Self-Care Tips:{RST}")
    for tip in result.get("tips", []):
        print(f"    {G}✓{RST} {tip}")

    print(f"\n  {BOLD}{C}Top Predictions:{RST}")
    for p in result.get("top3", []):
        bar_len = int(p["confidence"] * 20)
        bar = "█" * bar_len + "░" * (20 - bar_len)
        print(f"    {p['disease']:<30} {M}{bar}{RST} {p['confidence']:.1%}")

    print(f"\n{W}{'─'*56}{RST}")

    if result.get("see_doctor"):
        print(f"  {R}{BOLD}⚕  Please consult a healthcare professional.{RST}")
        print(f"{W}{'─'*56}{RST}")


def save_report_prompt(result):
    ans = input(f"\n  {Y}Save report to file? (y/n): {RST}").strip().lower()
    if ans == "y":
        from report_generator import generate_txt_report
        path = generate_txt_report(result, "CLI User")
        print(f"  {G}✓  Report saved to: {path}{RST}")


def setup_check():
    if not os.path.exists("dataset.csv"):
        print(f"  {Y}Generating dataset...{RST}")
        import subprocess
        subprocess.run([sys.executable, "build_dataset.py"], capture_output=True)

    if not os.path.exists("model.pkl"):
        print(f"  {Y}Training ML model (first run)...{RST}")
        from symptom_checker import train_model
        train_model()
        print(f"  {G}✓  Model ready.{RST}\n")


def main():
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    banner()
    setup_check()

    from symptom_checker import analyze_text

    print(f"  {W}Describe your symptoms in plain language.{RST}")
    print(f"  {DIM}Example: 'I have a high fever and body aches for 2 days'{RST}")
    print(f"  {DIM}Type 'quit' to exit.{RST}\n")

    while True:
        try:
            text = input(f"  {C}Your symptoms{RST} ❯  ").strip()
        except (KeyboardInterrupt, EOFError):
            print(f"\n\n  {M}Goodbye! Stay healthy. 🌿{RST}\n")
            break

        if not text:
            continue
        if text.lower() in ("quit", "exit", "q"):
            print(f"\n  {M}Goodbye! Stay healthy. 🌿{RST}\n")
            break

        progress_bar("Analyzing symptoms")
        result = analyze_text(text)

        if "error" in result:
            print(f"\n  {R}✗  {result['message']}{RST}")
            print(f"  {DIM}Try including keywords like: fever, cough, headache, nausea...{RST}\n")
            continue

        print_result(result)
        save_report_prompt(result)
        print()


if __name__ == "__main__":
    main()
