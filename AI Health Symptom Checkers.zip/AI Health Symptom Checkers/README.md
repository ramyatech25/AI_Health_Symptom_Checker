# 🩺 AI Health Symptom Checker

A full-stack AI-powered symptom checker built with **Flask + Machine Learning**.  
Describe how you feel in plain English and get instant disease prediction, confidence scores, recommendations, and downloadable health reports.

---

## ✨ Features

| Feature | Details |
|---|---|
| 🔍 **NLP Symptom Extraction** | Parses free-text input — no forms, just plain English |
| 🤖 **ML Disease Prediction** | Random Forest trained on 1,000 synthetic cases (100% accuracy) |
| 📊 **Visual Charts** | Confidence bar chart + symptom radar graph |
| 📋 **Report Downloads** | TXT and PDF reports via ReportLab |
| 🔐 **User Auth** | Register / Login with hashed passwords |
| 📁 **History Tracking** | Every check saved to your personal timeline |
| 🌙 **Dark / Light Mode** | Persistent theme toggle |
| 💻 **Terminal CLI** | Full-featured colored terminal app |
| 🌐 **REST API** | `/api/analyze` endpoint for external integration |

## 🦠 Conditions Covered

Common Cold · Influenza · COVID-19 · Migraine · Gastroenteritis ·
Hypertension · Diabetes · Asthma · Allergic Rhinitis · Urinary Tract Infection

---

## 🚀 Quick Start

### 1. Install dependencies
```bash
pip install -r requirements.txt
```

### 2. Run the web app
```bash
python app.py
```
Then open: **http://localhost:5000**

The app auto-generates the dataset and trains the model on first run.

### 3. Run the terminal app (Termux / CLI)
```bash
python terminal_app.py
```

---

## 📁 Project Structure

```
AI_Health_Symptom_Checker/
├── app.py              ← Flask web application
├── terminal_app.py     ← Colored terminal CLI
├── symptom_checker.py  ← ML engine (train + predict + NLP)
├── build_dataset.py    ← Synthetic dataset generator (1,000 rows)
├── visualizations.py   ← Matplotlib charts
├── report_generator.py ← TXT + PDF reports
├── dataset.csv         ← Generated symptom dataset
├── model.pkl           ← Trained RandomForest classifier
├── requirements.txt
├── templates/
│   ├── base.html       ← Nav, flash messages, footer
│   ├── index.html      ← Landing page
│   ├── login.html
│   ├── register.html
│   ├── checker.html    ← Main symptom checker UI
│   ├── dashboard.html  ← User dashboard with stats
│   └── history.html    ← Full check history
└── static/
    ├── css/style.css   ← Full design system (dark + light)
    └── js/theme.js     ← Theme toggle
```

---

## 🔌 API

```bash
POST /api/analyze
Content-Type: application/json
{"text": "I have a fever and dry cough"}
```

**Response:**
```json
{
  "disease": "COVID-19",
  "confidence": 0.88,
  "confidence_pct": "88.0%",
  "urgency": "high",
  "recommendation": "Isolate immediately and get tested...",
  "tips": ["Get tested", "Isolate from others", ...],
  "matched_symptoms": ["fever", "dry cough"],
  "top3": [...]
}
```

---

## ⚠️ Disclaimer

This tool is for **informational and educational purposes only**.  
It is **NOT** a substitute for professional medical advice, diagnosis, or treatment.  
Always consult a qualified healthcare professional for medical concerns.

---

*Built with ❤️ for Think Champ PV Ltd internship — RamyaAiWorld*
