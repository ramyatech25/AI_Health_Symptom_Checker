import os, json, uuid
from datetime import datetime
from functools import wraps
from flask import (Flask, render_template, request, redirect,
                   url_for, session, flash, jsonify, send_file)
from werkzeug.security import generate_password_hash, check_password_hash

from symptom_checker   import analyze_text, extract_symptoms, train_model
from visualizations    import confidence_bar_chart, symptom_radar_chart, history_trend_chart
from report_generator  import generate_txt_report, generate_pdf_report
from huggingface_helper import chatbot_reply, hf_enhance_prediction
from openai_engine     import (openai_analyze, openai_chatbot_reply,
                                ai_realtime_extract, engine_status, is_openai_ready)

app = Flask(__name__)
app.secret_key = "ramya-ai-health-secret-2024"
DB_FILE = "users_db.json"

# ── DB ────────────────────────────────────────────────────────────────────────
def load_db():
    if not os.path.exists(DB_FILE): return {}
    with open(DB_FILE) as f: return json.load(f)

def save_db(db):
    with open(DB_FILE,"w") as f: json.dump(db,f,indent=2)

def login_required(f):
    @wraps(f)
    def dec(*a,**k):
        if "username" not in session:
            flash("Please log in to continue.","warning")
            return redirect(url_for("login"))
        return f(*a,**k)
    return dec

# ── Auth ──────────────────────────────────────────────────────────────────────
@app.route("/")
def index():
    status = engine_status()
    return render_template("index.html", engine_status=status)

@app.route("/register", methods=["GET","POST"])
def register():
    if request.method == "POST":
        u = request.form.get("username","").strip()
        e = request.form.get("email","").strip()
        p = request.form.get("password","")
        db = load_db()
        if not u or not e or not p:   flash("All fields required.","error")
        elif u in db:                  flash("Username taken.","error")
        elif len(p) < 6:               flash("Password min 6 chars.","error")
        else:
            db[u] = {"email":e,"password":generate_password_hash(p),
                     "created":datetime.now().isoformat(),
                     "history":[],"chat_history":[]}
            save_db(db); session["username"] = u
            flash("Account created! Welcome.","success")
            return redirect(url_for("dashboard"))
    return render_template("register.html")

@app.route("/login", methods=["GET","POST"])
def login():
    if request.method == "POST":
        u = request.form.get("username","").strip()
        p = request.form.get("password","")
        db = load_db(); user = db.get(u)
        if user and check_password_hash(user["password"],p):
            session["username"] = u
            flash(f"Welcome back, {u}!","success")
            return redirect(url_for("dashboard"))
        flash("Invalid credentials.","error")
    return render_template("login.html")

@app.route("/logout")
def logout():
    session.clear(); flash("Logged out.","info")
    return redirect(url_for("index"))

# ── Dashboard ─────────────────────────────────────────────────────────────────
@app.route("/dashboard")
@login_required
def dashboard():
    db = load_db(); user = db.get(session["username"],{})
    history = user.get("history",[])
    chart_path = None
    if history:
        chart_path = history_trend_chart(history, filename=f"history_{session['username']}.png")
    return render_template("dashboard.html",
        username=session["username"], history=history,
        recent=history[-5:][::-1], chart_path=chart_path,
        total_checks=len(history), engine_status=engine_status())

# ── Checker ───────────────────────────────────────────────────────────────────
@app.route("/checker", methods=["GET","POST"])
@login_required
def checker():
    result = None; symptom_text = ""; conf_chart = radar_chart = None
    engine_used = "local"

    if request.method == "POST":
        symptom_text  = request.form.get("symptoms","").strip()
        force_engine  = request.form.get("engine","auto")   # auto | openai | local

        if symptom_text:
            # ── Choose engine ──────────────────────────────────────────────
            use_openai = (force_engine == "openai") or \
                         (force_engine == "auto" and is_openai_ready())

            if use_openai:
                result = openai_analyze(symptom_text)
                engine_used = "openai"
                # If OpenAI fails hard, fall back to local
                if result and result.get("error") == "openai_unavailable":
                    result = analyze_text(symptom_text)
                    engine_used = "local"
            else:
                result = analyze_text(symptom_text)
                engine_used = "local"

            if result and "error" not in result:
                # HF cross-verification (always try)
                result = hf_enhance_prediction(symptom_text, result)
                result["engine_used"] = engine_used

                # Charts
                conf_chart  = os.path.basename(
                    confidence_bar_chart(result["top3"], f"conf_{session['username']}.png"))
                radar_chart = os.path.basename(
                    symptom_radar_chart(result["matched_symptoms"], [],
                                        f"radar_{session['username']}.png"))
                # Save history
                db = load_db()
                entry = {
                    "id":               str(uuid.uuid4())[:8],
                    "date":             datetime.now().strftime("%Y-%m-%d %H:%M"),
                    "symptoms_text":    symptom_text,
                    "matched_symptoms": result.get("matched_symptoms",[]),
                    "disease":          result.get("disease","Unknown"),
                    "confidence":       result.get("confidence_pct","N/A"),
                    "urgency":          result.get("urgency","medium"),
                    "engine":           engine_used,
                }
                db[session["username"]]["history"].append(entry)
                session["last_disease"] = result.get("disease")
                session["last_result"]  = json.dumps(result)
                save_db(db)

    return render_template("checker.html",
        result=result, symptom_text=symptom_text,
        conf_chart=conf_chart, radar_chart=radar_chart,
        engine_used=engine_used, openai_ready=is_openai_ready(),
        engine_status=engine_status())

# ── Real-time AJAX ────────────────────────────────────────────────────────────
@app.route("/api/realtime", methods=["POST"])
@login_required
def api_realtime():
    data = request.get_json() or {}
    text = data.get("text","").strip()
    if len(text) < 6:
        return jsonify({"symptoms":[],"partial":True})
    # Prefer AI extraction if available
    if is_openai_ready():
        symptoms = ai_realtime_extract(text)
    else:
        symptoms = extract_symptoms(text)
    return jsonify({"symptoms": symptoms, "count": len(symptoms),
                    "partial": True, "engine": "openai" if is_openai_ready() else "local"})

# ── History ───────────────────────────────────────────────────────────────────
@app.route("/history")
@login_required
def history():
    db = load_db()
    user_history = db.get(session["username"],{}).get("history",[])[::-1]
    return render_template("history.html", history=user_history)

@app.route("/history/delete/<eid>", methods=["POST"])
@login_required
def delete_history(eid):
    db = load_db(); user = db.get(session["username"])
    if user:
        user["history"] = [h for h in user["history"] if h.get("id") != eid]
        save_db(db); flash("Entry deleted.","success")
    return redirect(url_for("history"))

# ── Chatbot ───────────────────────────────────────────────────────────────────
@app.route("/chatbot")
@login_required
def chatbot():
    db = load_db()
    chat_history = db.get(session["username"],{}).get("chat_history",[])[-20:]
    return render_template("chatbot.html",
        last_disease=session.get("last_disease"),
        chat_history=chat_history,
        openai_ready=is_openai_ready())

@app.route("/api/chat", methods=["POST"])
@login_required
def api_chat():
    data = request.get_json() or {}
    msg  = data.get("message","").strip()
    if not msg: return jsonify({"error":"Empty"}), 400

    disease = session.get("last_disease")
    db = load_db()
    raw_history = db.get(session["username"],{}).get("chat_history",[])

    # Use GPT chatbot if available, else rule-based
    if is_openai_ready():
        reply = openai_chatbot_reply(msg, disease, raw_history)
        engine = "openai"
    else:
        reply  = chatbot_reply(msg, disease)
        engine = "local"

    # Persist
    if session["username"] in db:
        ch = db[session["username"]].setdefault("chat_history",[])
        ch.append({"role":"user","text":msg,   "time":datetime.now().strftime("%H:%M")})
        ch.append({"role":"bot", "text":reply, "time":datetime.now().strftime("%H:%M"),"engine":engine})
        db[session["username"]]["chat_history"] = ch[-100:]
        save_db(db)

    return jsonify({"reply":reply,"disease_context":disease,"engine":engine})

@app.route("/api/chat/clear", methods=["POST"])
@login_required
def clear_chat():
    db = load_db()
    if session["username"] in db:
        db[session["username"]]["chat_history"] = []
        save_db(db)
    return jsonify({"status":"cleared"})

# ── Engine status API ─────────────────────────────────────────────────────────
@app.route("/api/engine/status")
@login_required
def api_engine_status():
    return jsonify(engine_status())

@app.route("/api/engine/set-key", methods=["POST"])
@login_required
def api_set_key():
    """Allow users to set their own OpenAI key from the UI (session-only)."""
    data = request.get_json() or {}
    key  = data.get("api_key","").strip()
    if key.startswith("sk-") and len(key) > 20:
        os.environ["OPENAI_API_KEY"] = key
        # Reset client so it picks up the new key
        import openai_engine as oe
        oe.OPENAI_API_KEY = key
        oe._client = None
        session["openai_key_set"] = True
        return jsonify({"status":"ok","message":"OpenAI API key activated for this session."})
    return jsonify({"status":"error","message":"Invalid API key format."}), 400

# ── Reports ───────────────────────────────────────────────────────────────────
@app.route("/report/txt", methods=["POST"])
@login_required
def download_txt():
    try:    result = json.loads(request.form.get("result_json","{}"))
    except: flash("Report error.","error"); return redirect(url_for("checker"))
    path = generate_txt_report(result, session["username"])
    return send_file(path, as_attachment=True, download_name="health_report.txt")

@app.route("/report/pdf", methods=["POST"])
@login_required
def download_pdf():
    try:    result = json.loads(request.form.get("result_json","{}"))
    except: flash("Report error.","error"); return redirect(url_for("checker"))
    path = generate_pdf_report(result, session["username"])
    if path: return send_file(path, as_attachment=True, download_name="health_report.pdf")
    flash("PDF unavailable, downloading TXT.","warning")
    path = generate_txt_report(result, session["username"])
    return send_file(path, as_attachment=True, download_name="health_report.txt")

# ── Charts ────────────────────────────────────────────────────────────────────
@app.route("/charts/<filename>")
@login_required
def serve_chart(filename):
    return send_file(os.path.join("charts", filename))

@app.route("/api/analyze", methods=["POST"])
def api_analyze():
    data = request.get_json() or {}
    text = data.get("text","")
    if not text: return jsonify({"error":"No text"}), 400
    if is_openai_ready():
        return jsonify(openai_analyze(text))
    return jsonify(analyze_text(text))

# ── Startup ───────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    if not os.path.exists("dataset.csv"):
        import subprocess; subprocess.run(["python","build_dataset.py"])
    if not os.path.exists("model.pkl"):
        train_model()
    st = engine_status()
    print(f"\n{'='*55}")
    print(f"  🩺 AI Health Symptom Checker")
    print(f"  OpenAI (GPT-4o-mini): {'✅ READY' if st['openai_ready'] else '❌ No API key — using local ML'}")
    print(f"  Local ML fallback:    ✅ Ready")
    print(f"  Set key: export OPENAI_API_KEY=sk-...")
    print(f"{'='*55}\n")
    app.run(debug=True, host="0.0.0.0", port=5000)
