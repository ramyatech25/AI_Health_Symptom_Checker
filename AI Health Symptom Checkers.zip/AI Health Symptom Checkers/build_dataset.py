import pandas as pd
import numpy as np
import random

random.seed(42)
np.random.seed(42)

DISEASES = {
    "Common Cold": {
        "symptoms": ["runny nose", "sneezing", "sore throat", "mild fever", "cough", "congestion", "fatigue"],
        "required": ["runny nose", "sneezing"],
        "weight": 0.15
    },
    "Influenza": {
        "symptoms": ["high fever", "body aches", "chills", "fatigue", "cough", "headache", "sore throat"],
        "required": ["high fever", "body aches"],
        "weight": 0.12
    },
    "COVID-19": {
        "symptoms": ["fever", "dry cough", "fatigue", "loss of taste", "loss of smell", "shortness of breath", "headache"],
        "required": ["fever", "dry cough"],
        "weight": 0.12
    },
    "Migraine": {
        "symptoms": ["severe headache", "nausea", "vomiting", "light sensitivity", "sound sensitivity", "visual aura"],
        "required": ["severe headache"],
        "weight": 0.10
    },
    "Gastroenteritis": {
        "symptoms": ["nausea", "vomiting", "diarrhea", "stomach cramps", "fever", "dehydration"],
        "required": ["nausea", "diarrhea"],
        "weight": 0.10
    },
    "Hypertension": {
        "symptoms": ["headache", "dizziness", "blurred vision", "chest pain", "shortness of breath", "nosebleed"],
        "required": ["headache", "dizziness"],
        "weight": 0.08
    },
    "Diabetes": {
        "symptoms": ["frequent urination", "excessive thirst", "fatigue", "blurred vision", "slow healing", "numbness"],
        "required": ["frequent urination", "excessive thirst"],
        "weight": 0.08
    },
    "Asthma": {
        "symptoms": ["wheezing", "shortness of breath", "chest tightness", "cough", "breathlessness"],
        "required": ["wheezing", "shortness of breath"],
        "weight": 0.07
    },
    "Allergic Rhinitis": {
        "symptoms": ["sneezing", "itchy eyes", "runny nose", "congestion", "watery eyes", "itchy throat"],
        "required": ["sneezing", "itchy eyes"],
        "weight": 0.08
    },
    "Urinary Tract Infection": {
        "symptoms": ["burning urination", "frequent urination", "pelvic pain", "cloudy urine", "fever", "back pain"],
        "required": ["burning urination", "frequent urination"],
        "weight": 0.10
    }
}

ALL_SYMPTOMS = list(set(
    s for d in DISEASES.values() for s in d["symptoms"]
))

def generate_row(disease_name, disease_info):
    row = {s: 0 for s in ALL_SYMPTOMS}
    selected = list(disease_info["required"])
    optional = [s for s in disease_info["symptoms"] if s not in disease_info["required"]]
    num_optional = random.randint(1, len(optional))
    selected += random.sample(optional, num_optional)
    for s in selected:
        row[s] = 1
    # add 0-2 noise symptoms
    noise = random.sample([s for s in ALL_SYMPTOMS if s not in selected], random.randint(0, 2))
    for s in noise:
        row[s] = 1
    row["disease"] = disease_name
    return row

rows = []
diseases = list(DISEASES.keys())
weights = [DISEASES[d]["weight"] for d in diseases]
total = sum(weights)
weights = [w / total for w in weights]

for _ in range(1000):
    disease = random.choices(diseases, weights=weights)[0]
    rows.append(generate_row(disease, DISEASES[disease]))

df = pd.DataFrame(rows)
df.to_csv("dataset.csv", index=False)
print(f"Dataset created: {len(df)} rows, {len(ALL_SYMPTOMS)} symptom features")
print(f"Disease distribution:\n{df['disease'].value_counts()}")
