import pandas as pd
import numpy as np
import pickle
import re
import os
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import LabelEncoder
from sklearn.metrics import accuracy_score, classification_report

# ── Symptom keyword map ────────────────────────────────────────────────────────
SYMPTOM_KEYWORDS = {
    "fever":              ["fever", "temperature", "feverish", "pyrexia", "hot"],
    "high fever":         ["high fever", "very high temperature", "104", "103", "burning fever"],
    "mild fever":         ["mild fever", "slight fever", "low grade fever", "low-grade fever"],
    "dry cough":          ["dry cough", "non-productive cough", "irritating cough"],
    "cough":              ["cough", "coughing", "coughs"],
    "runny nose":         ["runny nose", "runny", "nose running", "nasal discharge", "rhinorrhea"],
    "sneezing":           ["sneez", "achoo"],
    "sore throat":        ["sore throat", "throat pain", "painful throat", "scratchy throat"],
    "headache":           ["headache", "head pain", "head ache", "head hurts", "head is pounding"],
    "severe headache":    ["severe headache", "intense headache", "throbbing headache", "migraine headache"],
    "body aches":         ["body ache", "muscle ache", "myalgia", "body pain", "muscle pain", "aching"],
    "fatigue":            ["fatigue", "tired", "exhausted", "weakness", "lethargy", "weak", "no energy"],
    "nausea":             ["nausea", "nauseous", "feel sick", "queasy", "upset stomach"],
    "vomiting":           ["vomit", "throwing up", "puke", "vomiting"],
    "diarrhea":           ["diarrhea", "diarrhoea", "loose stool", "watery stool", "loose motion"],
    "stomach cramps":     ["stomach cramp", "abdominal cramp", "belly ache", "stomach pain", "tummy ache"],
    "shortness of breath":["shortness of breath", "breathless", "difficulty breathing", "can't breathe", "breathing problem"],
    "chest pain":         ["chest pain", "chest tightness", "chest discomfort", "chest pressure"],
    "chest tightness":    ["chest tightness", "tight chest", "constricted chest"],
    "wheezing":           ["wheez", "whistling breath", "noisy breathing"],
    "dizziness":          ["dizzy", "dizziness", "lightheaded", "light-headed", "vertigo", "spinning"],
    "blurred vision":     ["blurred vision", "blurry vision", "vision blur", "can't see clearly"],
    "loss of taste":      ["loss of taste", "can't taste", "no taste", "taste loss", "ageusia"],
    "loss of smell":      ["loss of smell", "can't smell", "no smell", "smell loss", "anosmia"],
    "congestion":         ["congestion", "stuffy nose", "blocked nose", "nasal congestion"],
    "chills":             ["chill", "shiver", "shivering", "shakes", "rigors"],
    "frequent urination": ["frequent urinat", "urinating often", "peeing often", "urinary frequency"],
    "burning urination":  ["burning urinat", "painful urinat", "burning when pee", "dysuria"],
    "excessive thirst":   ["excessive thirst", "very thirsty", "constant thirst", "polydipsia"],
    "pelvic pain":        ["pelvic pain", "lower abdominal pain", "lower belly pain"],
    "cloudy urine":       ["cloudy urine", "dark urine", "murky urine"],
    "back pain":          ["back pain", "lower back pain", "backache"],
    "itchy eyes":         ["itchy eye", "eye itch", "eyes itch", "watery itchy"],
    "watery eyes":        ["watery eye", "eyes watering", "tearing", "lacrimation"],
    "itchy throat":       ["itchy throat", "throat itch", "throat irritation"],
    "light sensitivity":  ["light sensitive", "photophobia", "sensitive to light"],
    "sound sensitivity":  ["sound sensitive", "phonophobia", "sensitive to noise", "noise sensitive"],
    "visual aura":        ["visual aura", "aura", "flashing lights", "zigzag vision"],
    "dehydration":        ["dehydrat", "dry mouth", "thirsty", "no fluids"],
    "nosebleed":          ["nosebleed", "nose bleed", "epistaxis"],
    "slow healing":       ["slow heal", "wounds heal slow", "cuts not healing"],
    "numbness":           ["numb", "numbness", "tingling", "pins and needles"],
    "breathlessness":     ["breathless", "out of breath", "winded"],
}

DISEASE_RECOMMENDATIONS = {
    "Common Cold": {
        "recommendation": "Rest, stay hydrated, and use over-the-counter cold remedies. Symptoms usually resolve in 7–10 days.",
        "urgency": "low",
        "doctor": False,
        "tips": ["Drink warm fluids", "Use saline nasal spray", "Get plenty of rest", "Avoid cold air"]
    },
    "Influenza": {
        "recommendation": "Rest and stay hydrated. Antiviral medications like oseltamivir work best within 48 hours. See a doctor if symptoms worsen.",
        "urgency": "medium",
        "doctor": True,
        "tips": ["Isolate yourself", "Take fever reducers", "Drink electrolytes", "Consult a doctor early"]
    },
    "COVID-19": {
        "recommendation": "Isolate immediately and get tested. Monitor oxygen levels. Seek emergency care if breathing becomes difficult.",
        "urgency": "high",
        "doctor": True,
        "tips": ["Get tested", "Isolate from others", "Monitor oxygen saturation", "Seek urgent care if breathless"]
    },
    "Migraine": {
        "recommendation": "Rest in a dark, quiet room. OTC pain relievers may help. Frequent migraines require prescription medication.",
        "urgency": "medium",
        "doctor": False,
        "tips": ["Avoid bright lights", "Apply cold compress", "Take prescribed medication", "Track triggers"]
    },
    "Gastroenteritis": {
        "recommendation": "Stay hydrated with oral rehydration solutions. Eat bland foods (BRAT diet). Seek care if dehydrated or symptoms persist > 48h.",
        "urgency": "medium",
        "doctor": False,
        "tips": ["Sip clear fluids", "Eat bananas, rice, toast", "Avoid dairy", "Wash hands frequently"]
    },
    "Hypertension": {
        "recommendation": "Monitor blood pressure regularly. Reduce salt, stress, and caffeine. Medication may be required — consult a doctor.",
        "urgency": "high",
        "doctor": True,
        "tips": ["Measure BP daily", "Reduce sodium intake", "Exercise regularly", "Limit alcohol"]
    },
    "Diabetes": {
        "recommendation": "Check blood glucose immediately. Lifestyle changes and medication are essential. Consult an endocrinologist.",
        "urgency": "high",
        "doctor": True,
        "tips": ["Monitor blood sugar", "Reduce carbohydrates", "Exercise regularly", "See a doctor soon"]
    },
    "Asthma": {
        "recommendation": "Use your rescue inhaler. Avoid triggers. If attack is severe, seek emergency care immediately.",
        "urgency": "high",
        "doctor": True,
        "tips": ["Use inhaler as prescribed", "Avoid allergens", "Keep windows closed", "Have rescue inhaler ready"]
    },
    "Allergic Rhinitis": {
        "recommendation": "Identify and avoid allergens. Antihistamines and nasal corticosteroids are effective first-line treatments.",
        "urgency": "low",
        "doctor": False,
        "tips": ["Take antihistamines", "Use air purifier", "Avoid outdoor allergens", "Try saline rinse"]
    },
    "Urinary Tract Infection": {
        "recommendation": "Drink plenty of water and see a doctor for antibiotic treatment. Untreated UTIs can progress to kidney infection.",
        "urgency": "medium",
        "doctor": True,
        "tips": ["Drink lots of water", "Urinate frequently", "Avoid caffeine", "See a doctor for antibiotics"]
    }
}

URGENCY_COLORS = {"low": "#22c55e", "medium": "#f59e0b", "high": "#ef4444"}


def extract_symptoms(text: str) -> list:
    """Extract known symptoms from free-text input."""
    text_lower = text.lower()
    found = []
    for symptom, keywords in SYMPTOM_KEYWORDS.items():
        for kw in keywords:
            if kw in text_lower:
                found.append(symptom)
                break
    return list(set(found))


def train_model(dataset_path="dataset.csv", model_path="model.pkl"):
    df = pd.read_csv(dataset_path)
    feature_cols = [c for c in df.columns if c != "disease"]
    X = df[feature_cols]
    y = df["disease"]

    le = LabelEncoder()
    y_enc = le.fit_transform(y)

    X_train, X_test, y_train, y_test = train_test_split(X, y_enc, test_size=0.2, random_state=42)

    clf = RandomForestClassifier(n_estimators=200, max_depth=12, random_state=42, n_jobs=-1)
    clf.fit(X_train, y_train)

    acc = accuracy_score(y_test, clf.predict(X_test))
    print(f"Model accuracy: {acc:.2%}")

    with open(model_path, "wb") as f:
        pickle.dump({"model": clf, "label_encoder": le, "features": feature_cols}, f)
    print(f"Model saved to {model_path}")
    return clf, le, feature_cols, acc


def load_model(model_path="model.pkl"):
    with open(model_path, "rb") as f:
        data = pickle.load(f)
    return data["model"], data["label_encoder"], data["features"]


def predict_disease(symptoms: list, model_path="model.pkl"):
    """Given a list of symptom strings, predict disease with confidence scores."""
    if not os.path.exists(model_path):
        return None

    clf, le, features = load_model(model_path)

    # Build feature vector
    row = {f: 0 for f in features}
    for s in symptoms:
        if s in row:
            row[s] = 1

    X = pd.DataFrame([row])[features]
    proba = clf.predict_proba(X)[0]
    pred_idx = np.argmax(proba)
    pred_disease = le.inverse_transform([pred_idx])[0]
    confidence = float(proba[pred_idx])

    # Top 3 predictions
    top3_idx = np.argsort(proba)[::-1][:3]
    top3 = [
        {"disease": le.inverse_transform([i])[0], "confidence": float(proba[i])}
        for i in top3_idx
    ]

    rec = DISEASE_RECOMMENDATIONS.get(pred_disease, {
        "recommendation": "Please consult a healthcare professional for a proper diagnosis.",
        "urgency": "medium",
        "doctor": True,
        "tips": ["See a doctor"]
    })

    return {
        "disease": pred_disease,
        "confidence": confidence,
        "confidence_pct": f"{confidence:.1%}",
        "urgency": rec["urgency"],
        "urgency_color": URGENCY_COLORS.get(rec["urgency"], "#6b7280"),
        "recommendation": rec["recommendation"],
        "see_doctor": rec["doctor"],
        "tips": rec["tips"],
        "top3": top3,
        "matched_symptoms": symptoms,
    }


def analyze_text(text: str, model_path="model.pkl"):
    """Full pipeline: text → symptoms → prediction."""
    symptoms = extract_symptoms(text)
    if not symptoms:
        return {"error": "no_symptoms", "message": "No recognizable symptoms found. Please describe your symptoms in more detail."}
    result = predict_disease(symptoms, model_path)
    if result is None:
        return {"error": "no_model", "message": "Model not found. Please run setup first."}
    return result
